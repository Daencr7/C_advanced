#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DATABASE_PATH "/home/edna/Source_Code/C_src/Data/Database.csv"

typedef struct {
    char *name;
    int age;
    char *addr;
    char *phone;
} User;

typedef struct Node{
    User info;
    struct Node *next;
} Node;
Node* makeNode (User user){
    Node *new_node = (Node *)malloc(sizeof(Node));
    new_node->info = user;
    new_node->next = NULL;
}
void add_node(Node **head, User data)
{
    Node *new_node = makeNode(data);
    if(*head == NULL){*head = new_node;return;}
    Node *tmp = *head;
    while (tmp->next !=NULL)
    {
        tmp = tmp->next;
    }
    tmp->next = new_node;
}

void free_user(User *user){
    free(user->name);
    free(user->addr);
    free(user->phone);
}
// void readCSV(const char *filename, Node head){
//     FILE *file = fopen(filename, "r");
//     if(file==NULL) printf("Cannot open file\n");
//     char line[100];
//     fgets(line, sizeof(line), file);
//     while(fgets(line, sizeof(line),file)){
//         User user;
//         char *token = strtok(line,",");
//         user.name = (char*)malloc(strlen(token)+1);
//         strcpy(user.name, token);
        
//         token = strtok(NULL,",");
//         user.age = atoi(token);

//         token = strtok(NULL,",");
//         user.addr = (char*)malloc(strlen(token)+1);
//         strcpy(user.addr, token);

//         token = strtok(NULL,",");
//         user.phone = (char*)malloc(strlen(token)+1);
//         strcpy(user.phone, token);
//         add_node(&head,user);
//         // printf("%-20s %-5d\t %-20s\t %-15s\n", user.name, user.age, user.addr, user.phone);
//     }
// }
// void print_list(Node *head)
// {
//     while (head != NULL)
//     {
//         printf("%s ", head->info.name);
//         head = head->next;
//     }
//     printf("\n");
// }

int main(){
    Node *head = NULL;
    // readCSV(DATABASE_PATH,*head);
    FILE *file = fopen(DATABASE_PATH, "r");
    if(file==NULL) printf("Cannot open file\n");
    char line[100];
    fgets(line, sizeof(line), file);
    while(fgets(line, sizeof(line),file)){
        User user;
        char *token = strtok(line,",");
        user.name = (char*)malloc(strlen(token)+1);
        strcpy(user.name, token);
        
        token = strtok(NULL,",");
        user.age = atoi(token);

        token = strtok(NULL,",");
        user.addr = (char*)malloc(strlen(token)+1);
        strcpy(user.addr, token);

        token = strtok(NULL,",");
        user.phone = (char*)malloc(strlen(token)+1);
        strcpy(user.phone, token);
        printf("%s\n", user.name);
        // add_node(&head, user);
        free_user(&user);
    }
    fclose(file);
    // print_list(head);


    return 0;
}