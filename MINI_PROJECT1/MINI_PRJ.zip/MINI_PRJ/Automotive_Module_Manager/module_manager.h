#ifndef MODULE_MANAGER__H
#define MODULE_MANAGER__H
#define OFF 0
#define ON 1
#define INCREASETEMP 2
#define DECREASETEMP 3

#define ENGINE 0
#define ABS 1
#define LIGHT 2
#define AIR 3
#define TEMP 4

#define PUBLIC 0
#define PRIVATE 1

#include<stdint.h>

typedef uint8_t CarID;
typedef uint8_t CarName;
typedef uint8_t CarStatus;
typedef uint8_t CarAccess;
typedef uint8_t CarControl;

typedef struct {
    CarID ID : 8;
    CarName NAME : 8;
    CarStatus STATUS : 1;
    CarAccess ACCESS : 2;
    CarControl CONTROL : 3;
}Carmodule;

void configureModulecar(Carmodule *module, CarID id, CarName name, CarStatus status, CarAccess access, CarControl control);
void clearModulecar(Carmodule *Module, CarID id);
void setControl(Carmodule *module, CarControl control);
void displayModulecar(const Carmodule module);



#endif