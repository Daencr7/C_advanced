#include <stdio.h>
#include <stdint.h>
#include "bitmask_utils.h"

#define OFF 0
#define ON 1
#define INCREASETEMP 2
#define DECREASETEMP 3

#define ENGINE 0
#define ABS 1
#define LIGHT 2
#define AIR 3
#define TEMP 4

#define PUBLIC 0
#define PRIVATE 1

typedef uint8_t CarID;
typedef uint8_t CarName;
typedef uint8_t CarStatus;
typedef uint8_t CarAccess;
typedef uint8_t CarControl;

typedef struct {
    CarID ID : 8;
    CarName NAME : 8;
    CarStatus STATUS : 1;
    CarAccess ACCESS : 2;
    CarControl CONTROL : 3;
}Carmodule;

void configureModulecar(Carmodule *module, CarID id, CarName name, CarStatus status, CarAccess access, CarControl control){
    module->ID = id;
    module->NAME = name;
    module->STATUS = status;
    module->ACCESS = access;
    module->CONTROL = control;
}
void clearModulecar(Carmodule *Module, CarID id){

}
void setControl(Carmodule *module, CarControl control){
    module->CONTROL = control;
}
void displayModulecar(const Carmodule module) {
    const char *id[] = {"DC1","P1","D1","DH1","HD1"};
    const char *name[] = {"Dong Co","ABS","Den","Dieu Hoa","CB Nhiet Do"};

    const char *access[] = {"PUBLIC","PRIVATE"};
    const char *control[] = {"Turn Off","Turn On","Giam Nhiet","Tang Nhiet" };
    printf("---------------------------------------");
    printf("Car Module:\n");
    printf("Id: %s\n", id[module.ID]);
    printf("Name: %s\n", name[module.NAME]);
    printf("---------------------------------------");
    printf("Status:\n");
    printf("- ON: %s\n",(module.STATUS & STATUS_ON)? "Yes":"No" );
    printf("- ERROR: %s\n",(module.STATUS & STATUS_ERROR)? "Yes":"No" );
    printf("- WARNING: %s\n",(module.STATUS & STATUS_WARNING)? "Yes":"No" );
    printf("---------------------------------------");
    printf("Access: %s\n", access[module.ACCESS]); 
    printf("Control: %s\n", control[module.CONTROL]);
}
int main(){
    Carmodule *module = (Carmodule*)malloc(5*sizeof(Carmodule));


}