#ifndef FUNCTION_HANDLER__H
#define FUNCTION_HANDLER__H

void (*ptrfunc)();
void turnOnModule_status();
void turnOffModule_status();
void checkModule_status();
void controlActivity_INC();
void controlActivity_DEC();
#endif
