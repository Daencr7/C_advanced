#include <stdio.h>
#include "module_manager.h"
#define STATUS_OFF (0 << 0)
#define STATUS_ON (1 << 0)
#define STATUS_ERROR (1 << 1)
#define STATUS_WARNING (1 << 2)

void setStatus(Carmodule *module, CarStatus status){
    module->STATUS |= status;
}
void unsetStatus(Carmodule *module, CarStatus status){
    module->STATUS &= ~status;
}