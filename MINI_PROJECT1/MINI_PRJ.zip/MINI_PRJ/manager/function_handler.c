#include <stdio.h>
#include "bitmask_utils.h"
#include "Automotive_Module_Manager/module_manager.h"
// int cnt = 0;
void (*ptrfunc)();
extern Carmodule *module;
void turnOnModule_status(){
    ptrfunc = setStatus;
    ptrfunc(&module,STATUS_ON);
}

void turnOffModule_status(){
    ptrfunc = setStatus;
    ptrfunc(&module,STATUS_OFF);
}
void checkModule_status(){
    ptrfunc = displayModulecar;
    ptrfunc(module);
}
void controlActivity_INC(){
    ptrfunc = setControl;
    ptrfunc(&module,INCREASETEMP);
}
void controlActivity_DEC(){
    ptrfunc = setControl;
    ptrfunc(&module,DECREASETEMP);
}
// int main(){
    
//     // enter1();
//     return 0;
// }